const fs = require('fs');
fs.writeFileSync('text-file.txt', 'this is the content of a text file that would supprise you');